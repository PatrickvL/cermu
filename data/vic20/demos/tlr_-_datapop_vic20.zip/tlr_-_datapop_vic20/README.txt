README.txt
----------

Name:         Datapop!
Author:       tlr
Release Date: 2009-10-12

Datapop is a music demo for the unexpanded Commodore Vic-20 computer.
Runs best on PAL but works on NTSC (wrong tempo), should run in all
memory configurations.

The core of the demo is my new player: Ultraplayer!  

Ultraplayer uses tight control of the 4 oscillators to provide 9 bits
of frequency resolution and up to 6 bits of PWM.  All you hear is the 
original VIC oscillators.  No volume register modulations.

The player and most of the music was completed in February 2009.
Some fine adjustments was made to the music later.

Hold <SHIFT> to see some player gore.

Quick player notes:
- Tight oscillator control.  9 bits frequency, 6 bits PWM
- jmp/jsr/rts based pattern sequencing with transpose.
- Table based arpeggios/waveform.
- Table based PWM control.
- Table based vibrato control.

Stockholm, Sweden  2009-10-12
/Daniel Kahlin (aka tlr)

eof
